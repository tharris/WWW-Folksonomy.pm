#!/usr/bin/perl -w
use strict;

unlink 'GGB.def';
unlink 'cgi-bin/gbrowse';
unlink 'cgi-bin/gbrowse_img';
unlink 'cgi-bin/gbrowse_details';
unlink 'cgi-bin/gbrowse_syn';
